from .candidate_admin import CandidateAdmin
from .job_admin import JobAdmin
from .assessment_admin import AssessmentAdmin
